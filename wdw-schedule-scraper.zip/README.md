# WDW Schedule Scraper
## Authors and Contributors
- Ace Baugh

## Description
### Reason
There used to be an app that would easily grab schedules from the WDW Schedule app. With the new security in place this is nigh impossible. This app intends to replace the old one and be used on chrome browsers to add schedules to a google calendar with a simple button press.

### Functionality
- Grabs schedule information from secure website after page has been loaded for 5 seconds
- Copies data to the computer's clipboard
- *BONUS* WDW Schedule Scraper CSS file
  - Adds color to Schedule View Website

### About
- Copyright 2023
- Version 2.0.0

### Desired functionality
- Connect to google calendar api
- Check for duplicates in current calendar
- Replace outdated shifts with correct ones (if schedule changes)
- Add schedules to a google calendar with a simple button press
- Automatically check for schedule changes at 5pm and update calendar accordingly